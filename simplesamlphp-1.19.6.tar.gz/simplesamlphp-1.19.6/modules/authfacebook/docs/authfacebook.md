Using the Facebook authentication source with SimpleSAMLphp
===========================================================

Remember to configure `authsources.php`, with both App ID (or API Key) and App Secret.

To get an App ID/API Key and secret, register the application at:

 * <http://www.facebook.com/developers/>

Note: requests with App ID should be faster <https://github.com/facebook/php-sdk/issues/214>.

This module needs the CURL and JSON PHP extensions.

