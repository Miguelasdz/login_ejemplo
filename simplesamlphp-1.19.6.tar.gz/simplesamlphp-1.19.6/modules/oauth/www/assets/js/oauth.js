document.addEventListener('DOMContentLoaded', function () {
    $("#tabdiv").tabs();
});
